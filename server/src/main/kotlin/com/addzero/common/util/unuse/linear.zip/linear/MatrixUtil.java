package com.addzero.jlstarter.common.util.linear.sol;

import org.apache.commons.lang3.tuple.Triple;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static com.addzero.jlstarter.common.util.linear.sol.VectorGenerator.generateStream;

public class MatrixUtil {
    /**
     * 计算并返回给定矩阵的转置矩阵
     *
     * @param matrix 原始矩阵
     * @return double[][] 转置后的矩阵
     */
    public static double[][] transposeMatrix(double[][] matrix) {
        int m = matrix.length; // 获取原始矩阵的行数
        int n = matrix[0].length; // 获取原始矩阵的列数
        double[][] transposedMatrix = new double[n][m]; // 初始化转置矩阵

        // 计算转置矩阵
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                transposedMatrix[j][i] = matrix[i][j];
            }
        }

        return transposedMatrix;
    }

    // 通用方法：将任意维度的Integer数组转换为一维double数组

    // 辅助方法：将一维Integer数组转换为double数组
    private static <T extends Number> double[] convert2double(T[] numberArray) {
        return Arrays.stream(numberArray)
                .mapToDouble(Number::doubleValue)
                .toArray();
    }


    public static <T extends Number> double[][] convert2double(T[][] numberArray2D) {
        return Arrays.stream(numberArray2D).map(ts -> Arrays.stream(ts)
                        .mapToDouble(Number::doubleValue)
                        .toArray())
                .toArray(double[][]::new);
    }



    @SuppressWarnings("unchecked")
    public static <T> T[][] createMatrix(int m, int n, T initValue) {
        T[][] matrix = (T[][]) Array.newInstance((Class<? super T>) initValue.getClass(), m, n);
        for (int i = 0; i < m; i++) {
            Object[] row = (Object[]) Array.newInstance(initValue.getClass(), n);
            for (int j = 0; j < n; j++) {
                Array.set(row, j, initValue);
            }
            Array.set(matrix, i, row);
        }
        return matrix;
    }

    public static <T> T[][] createMatrixWithNthElementsOne(int m, int n, T initValue, int nth) {
        T[][] originalMatrix = createMatrix(m, n, initValue);
        T[][] newMatrix = (T[][]) Array.newInstance((Class<? super T>) initValue.getClass(), m, n);
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if ((i * n + j) % nth == 0) {
                    Array.set(newMatrix[i], j, 1);
                } else {
                    Array.set(newMatrix[i], j, originalMatrix[i][j]);
                }
            }
        }
        return newMatrix;
    }

    public static <T> T getMatrixElement(T[][] matrix, int i, int j) {
        if (matrix == null || i < 0 || j < 0 || i >= matrix.length || j >= matrix[0].length) {
            throw new IllegalArgumentException("Invalid matrix coordinates: (" + i + ", " + j + ")");
        }
        return matrix[i][j];
    }


    public static <T> T[][] setMatrixElements(T[][] matrix, Triple<Integer, Integer, T>... setConfig) {
        // 确保传入的配置不为空


        // 创建一个新的矩阵副本，避免修改原矩阵
        T[][] ret = (T[][]) Array.newInstance(matrix[0].getClass(), matrix.length);
        IntStream.range(0, matrix.length).forEach(i -> {
            ret[i] = (T[]) Array.newInstance(matrix[0][0].getClass(), matrix[0].length);
            System.arraycopy(matrix[i], 0, ret[i], 0, matrix[i].length);
        });

        // 创建一个Map来存储要修改的索引-值对，避免多次遍历
        Map<Integer, Map<Integer, T>> modifications = Arrays.stream(setConfig)
                .collect(Collectors.groupingBy(Triple::getLeft, Collectors.toMap(Triple::getMiddle, Triple::getRight)));

        modifications.forEach((rowIndex, colModifications) -> {
            colModifications.forEach((colIndex, value) -> {
                if (colIndex >= 0 && colIndex < ret[rowIndex].length) {
                    ret[rowIndex][colIndex] = value;
                }
            });
        });

        return ret;
    }

    /**
     * 返回每隔开k修改矩阵
     */
    public static <T> List<T[]> setIntervalElementsFromTriples(T[][] matrix, int k) {
        // 确保原矩阵不为空
        if (matrix == null || matrix.length == 0 || matrix[0].length == 0) {
            throw new IllegalArgumentException("Matrix cannot be null or empty.");
        }
        int m = matrix.length;
        int n = matrix[0].length;
        int def = m * n;
        Stream<int[]> stream = generateStream(def, k);


        List<T[]> collect = stream.map(e -> {
            Triple<Integer, Integer, T>[] array = Arrays.stream(e).mapToObj(el -> {
                Triple<Integer, Integer, Integer> integerIntegerIntegerTriple = Triple.of(0, el, 1);
                return integerIntegerIntegerTriple;
            }).toArray(Triple[]::new);

            T[][] ts = setMatrixElements(matrix, array);
            T[] t = ts[0];
            return t;
        }).collect(Collectors.toList());
        return
                collect;
    }


    public static void main(String[] args) {
        Integer[][] matrix = createMatrix(1, 12, 0);

        Triple<Integer, Integer, Integer> integerIntegerIntegerTriple = Triple.of(0, 1, 1);
        Triple<Integer, Integer, Integer> integerIntegerIntegerTriple2 = Triple.of(0, 4, 1);
        Triple<Integer, Integer, Integer> integerIntegerIntegerTriple23 = Triple.of(0, 8, 1);

        Triple<Integer, Integer, Integer> integerIntegerIntegerTriple2222 = Triple.of(0, 4, 1);
        Triple<Integer, Integer, Integer> integerIntegerIntegerTriple22 = Triple.of(0, 5, 1);
        Triple<Integer, Integer, Integer> integerIntegerIntegerTriple223 = Triple.of(0, 6, 1);
        Triple<Integer, Integer, Integer> integerIntegerIntegerTriple42 = Triple.of(0, 7, 1);

        Triple<Integer, Integer, Integer> jdoais = Triple.of(0, 8, 1);
        Triple<Integer, Integer, Integer> saodijosa = Triple.of(0, 9, 1);
        Triple<Integer, Integer, Integer> osajdoa = Triple.of(0, 10, 1);
        Triple<Integer, Integer, Integer> asoidjoasi = Triple.of(0, 11, 1);


//        List<Integer[]> integers2 = setIntervalElementsFromTriples(matrix, 4);
//        System.out.println(integers2);

    }


}
