package com.addzero.jlstarter.common.util.linear.tt;

import com.addzero.jlstarter.common.util.linear.sol.MatrixUtil;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.optim.PointValuePair;
import org.apache.commons.math3.optim.linear.*;
import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class LinearProgrammingSolver2 {

    public static void main(String[] args) {
        double[] zbs = {180, 20, 500, 200, 600}; // 库存需求
        double[][] capacities = {
                {3, 2, 0, 0, 50},
                {6, 0, 5, 0, 10},
                {0, 0, 0, 6, 20},
                {0, 0, 0, 7, 30}
        };


        //四种类型的船再三条作业线各自的价格(广义理解为权重即可)
        double[][] 定义价格矩阵 = {
                {5000, 7000, 6500, 8000},
                {5000, 7000, 6500, 8000},
                {5000, 7000, 6500, 8000},
        };


        double[] lineConfigurations = {60, 70, 40}; // 载具数量约束

//        double[] doubles = solveLinearProgramming(zbs, capacities, lineConfigurations,定义价格矩阵);
        double[] doubles = solveLinearProgramming(zbs, capacities, lineConfigurations);

    }

    public static double[] solveLinearProgramming(double[] zbs, double[][] capacities, double[] lineConfigurations) {
        int n = capacities.length;
        int m = lineConfigurations.length;
        int dimension = n * m; // 总变量数
        int zbTypeSize = zbs.length;
        int numConstraints = zbTypeSize + m; // 总约束数

        // 默认价格矩阵为全0，表示最小化运输成本
        double[][] defaultPriceMatrix = new double[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                defaultPriceMatrix[i][j] = 0;
            }
        }
        return solveLinearProgramming(zbs, capacities, lineConfigurations, defaultPriceMatrix);
    }

    public static double[] solveLinearProgramming(double[] zbs, double[][] capacities, double[] lineConfigurations, double[][] priceMatrix) {
        //行
//        int m = lineConfigurations.length;
//
//        //列
//        int n = capacities.length;
//
//        int zbTypeSize = zbs.length;
//
//        //纬度
//        int dimension = m * n;


        int n = capacities.length;
        int m = lineConfigurations.length;
        int dimension = n * m; // 总变量数
        int zbTypeSize = zbs.length;
        int numConstraints = zbTypeSize + m; // 总约束数


        // 构造约束条件

//       初始化矩阵
//        Integer[][] matrix = MatrixUtil.createMatrix(m, n, 1);
//        double[][] doubles1 = MatrixUtil.convert2double(matrix);
        // 构建约束条件
//        List<LinearConstraint> constraints = new ArrayList<>();
        //初始解空间基底


        //       初始化矩阵
        Integer[][] matrix = MatrixUtil.createMatrix(1, m * n, 0);
        // 构建约束条件
        List<LinearConstraint> constraints = new ArrayList<>();
//        x1,x2,x3,x4
        List<Integer[]> 特征行变量 = MatrixUtil.setIntervalElementsFromTriples(matrix, n);


        List<double[]> doubleList = 特征行变量.stream()
                .map(arr -> Arrays.stream(arr)
                        .mapToDouble(Integer::doubleValue)
                        .toArray())
                .collect(Collectors.toList());


//        作业线船数量约束
        List<LinearConstraint> collect = Stream.iterate(0, (i) -> ++i).limit(m).map(i -> {
            double[] doubles = doubleList.get(i);
            LinearConstraint linearConstraint = new LinearConstraint(doubles, Relationship.EQ, lineConfigurations[i]);
            return linearConstraint;
        }).collect(Collectors.toList());
        constraints.addAll(collect);


        //运力约束
        for (int k = 0; k < zbTypeSize; k++) {
            double[] capacityConstraintCoefficients = new double[m * n];
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    int index = i * n + j; // 计算索引
                    capacityConstraintCoefficients[index] = capacities[j][k]; // 赋值系数
                }
            }
            LinearConstraint capacityConstraint = new LinearConstraint(capacityConstraintCoefficients, Relationship.GEQ, zbs[k]);
            constraints.add(capacityConstraint);
        }


// 将非负约束添加到约束集合中
        List<LinearConstraint> nonNegConstraints = getLinearConstraints(dimension);
        constraints.addAll(nonNegConstraints);


        // 定义目标函数（这里可以是任意合法目标，但根据问题描述，我们更关心约束满足）
        // 初始化决策变量系数（目标函数系数，这里假设目标是无特定优化，全为0）
//        double[] objectiveCoefficients = new double[dimension];
//        Arrays.fill(objectiveCoefficients, 0);
//        LinearObjectiveFunction objectiveFunction = new LinearObjectiveFunction(objectiveCoefficients, 0);


        // 这里是原有的求解逻辑，但是目标函数的系数现在应该包含价格矩阵
        double[] objectiveCoefficients = new double[dimension];
        // 将价格矩阵的元素添加到目标函数的系数中
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                int index = i * n + j; // 计算索引
                objectiveCoefficients[index] = priceMatrix[i][j]; // 负号表示我们想最小化成本
            }
        }

        // 重新定义目标函数
        LinearObjectiveFunction objectiveFunction = new LinearObjectiveFunction(objectiveCoefficients, 0);


        // 定义优化问题
        // 创建约束条件集
        LinearConstraintSet constraintSet = new LinearConstraintSet(constraints);
        //        // 使用SimplexSolver求解
        SimplexSolver solver = new SimplexSolver();
        PointValuePair solution = solver.optimize(
                objectiveFunction,
                constraintSet,
                GoalType.MINIMIZE // 我们的目标是最小化
        );

        //打印结果
        System.out.println("决策变量为：" + Arrays.toString(solution.getPoint()));
        System.out.println("最优值为：" + solution.getValue());
        double[] point = solution.getPoint();

        return point;
    }


    private static RealMatrix createDecisionVariableMatrix(int m, int n) {
        double[][] coefficients = new double[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                coefficients[i][j] = 1;
            }
        }
        return new Array2DRowRealMatrix(coefficients);
    }

    /**
     * 非负约束列表
     *
     * @param dimension
     * @return {@link List }<{@link LinearConstraint }>
     */
    private static List<LinearConstraint> getLinearConstraints(int dimension) {
        // 非负约束列表
        List<LinearConstraint> nonNegConstraints = new ArrayList<>();

// 为每个变量 xi 创建非负约束 xi >= 0
        for (int i = 0; i < dimension; i++) {
            // 创建一个新数组，其中第 i 个元素是 1（表示变量 xi），其余元素是 0
            double[] coeffs = new double[dimension];
            coeffs[i] = 1;

            // 添加约束 xi >= 0
            nonNegConstraints.add(new LinearConstraint(coeffs, Relationship.GEQ, 0));
        }
        return nonNegConstraints;
    }
}
