package com.addzero.jlstarter.common.util.linear.sol;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class VectorGenerator {

    /**
     //    int m = 3; // 行数
     //        int n = 4; // 列数
     //        int[] indices = {1, 5, 9}; /
    [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0] / 给定的索引

     * @param m
     * @param n
     * @param indices
     * @return {@link double[] }
     */
    public static double[] generateVector(int m, int n, int[] indices) {
        double[] vector = new double[m * n];

        for (int index : indices) {
            if (index >= 0 && index < m * n) {
                vector[index-1] = 1;
            } else {
                throw new IllegalArgumentException("Index out of bounds: " + index);
            }
        }

        return vector;
    }

    public static void main(String[] args) {
        int m = 3; // 行数
        int n = 4; // 列数
        int[] indices = {1, 5, 9}; // 给定的索引


        double[] resultVector = generateVector(m, n, indices);
    }

    /**
     * 每隔k set为1
     * @param def
     * @param k
     * @return {@link Stream }<{@link int[] }>
     */
    public static Stream<int[]> generateStream(int def, int k) {
        int times = def / k;
        return IntStream.range(0, times)
                .mapToObj(i -> IntStream.range(i * k, (i + 1) * k).toArray());
    }
}
