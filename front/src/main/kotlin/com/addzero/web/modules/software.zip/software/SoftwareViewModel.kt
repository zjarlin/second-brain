package com.addzero.web.modules.software

import androidx.compose.runtime.*
import com.addzero.web.base.BaseViewModel
import com.addzero.web.infra.jimmer.base.pagefactory.PageResult
import com.addzero.web.shared.PlatformType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class SoftwareViewModel : BaseViewModel<Software>() {
    private val service = SoftwareService()

    init {
        loadData()
    }

    fun searchSoftware(
        keyword: String = "",
        platform: PlatformType = PlatformType.ALL,
        osTypes: Set<OsType> = emptySet(),
        useAI: Boolean = false,
        page: Int = currentPage,
        size: Int = pageSize
    ) {
        api {
            val result = service.searchSoftware(
                keyword = keyword,
                platform = if (platform == PlatformType.ALL) null else platform,
                osTypes = osTypes.filter { it != OsType.ALL }.takeIf { it.isNotEmpty() },
                useAI = useAI,
                page = page,
                size = size
            )
            items = result.content
            totalPages = result.totalPages
            totalElements = result.totalElements
            currentPage = result.pageNumber
            pageSize = result.pageSize
        }
    }

    fun nextPage() {
        if (currentPage < totalPages - 1) {
            searchSoftware(page = currentPage + 1)
        }
    }

    fun previousPage() {
        if (currentPage > 0) {
            searchSoftware(page = currentPage - 1)
        }
    }

    fun downloadSoftware(software: Software): ByteArray? {
        var result: ByteArray? = null
        api {
            result = service.downloadSoftware(software.id)
        }
        return result
    }
}
