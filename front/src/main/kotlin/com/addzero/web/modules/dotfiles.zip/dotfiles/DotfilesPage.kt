package com.addzero.web.modules.dotfiles

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.addzero.web.modules.second_brain.dotfiles.BizDotfiles
import com.addzero.web.modules.second_brain.dotfiles.EnumOsType
import com.addzero.web.modules.second_brain.dotfiles.Enumplatforms
import com.addzero.web.ui.components.crud.Pagination
import com.addzero.web.ui.components.system.dynamicroute.MetaSpec
import com.addzero.web.ui.components.system.dynamicroute.RouteMetadata
import org.babyfish.jimmer.sql.kt.ast.expression.rowCount

class DotfilesPage : MetaSpec {

    override val metadata: RouteMetadata
        get() = RouteMetadata(
//            refPath = this.javaClass.name,
            parentName = "管理",
            title = "Dotfiles管理",
            icon = Icons.Filled.Settings,
            visible = true,
            permissions = emptyList()
            , order = 50.0
        )


    @Composable
    override fun render() {
        val scope = rememberCoroutineScope()
        val viewModel = remember { DotfilesViewModel() }

        // 搜索条件状态
        var searchName by remember { mutableStateOf("") }
        var selectedPlatforms by remember { mutableStateOf(setOf<Enumplatforms>()) }
        var selectedOSTypes by remember { mutableStateOf(setOf<EnumOsType>()) }

        /* 处理编辑 */
        // 分页控制插槽
        Row {
            // 搜索区域插槽
            DotFilesSearchPanel(
                searchName = searchName,
                onSearchNameChange = { searchName = it },
                selectedPlatforms = selectedPlatforms,
                onPlatformSelectionChange = { selectedPlatforms = it },
                selectedOSTypes = selectedOSTypes,
                onOSTypeSelectionChange = { selectedOSTypes = it },
                onSearch = {
                    viewModel.loadData(
                        name = searchName, platforms = selectedPlatforms, osTypes = selectedOSTypes
                    )
                })

            Spacer(modifier = Modifier.height(16.dp))

            // 操作按钮插槽
            ImportExportButtons(scope, viewModel)

            // 加载状态
            if (viewModel.isLoading) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
            }

            // 错误提示
            viewModel.error
                // 搜索区域插槽
                // 操作按钮插槽
                // 主内容区插槽
                ?.let { errorMsg ->
                Text(
                    text = errorMsg,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp)
                )
            }

            // 主内容区插槽
            /* 处理编辑 */
            /* 处理编辑 */DotfilesTable(
            items = viewModel.pageResult?.content ?: emptyList<BizDotfiles>(),
            onEdit = { /* 处理编辑 */ },
            onDelete = { viewModel.deleteDotfile(it.id) },
            currentPage = viewModel.currentPage,
            totalPages = viewModel.pageResult?.totalPages ?: 1,
            onPageChange = { newPage ->
                viewModel.loadData(page = newPage)
            })

            // 分页控制插槽
            viewModel.pageResult?.let { result ->
                Pagination(
                    pageResult = result, onPrevious = viewModel::previousPage, onNext = viewModel::nextPage
                )
            }
        }
    }

}
