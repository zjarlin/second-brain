package com.addzero.web.modules.software

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.addzero.web.modules.second_brain.dotfiles.Enumplatforms
import com.addzero.web.modules.second_brain.dotfiles.EnumOsType
import com.addzero.web.ui.components.crud.SelectionPanel

@Composable
fun SearchPanel(
    modifier: Modifier = Modifier,
    onSearch: (SearchCriteria) -> Unit,
    onAiSearch: (SearchCriteria) -> Unit
) {
    var searchText by remember { mutableStateOf("") }

    val platformSelection = SelectionPanel(
        title = "平台类型",
        items = Enumplatforms.entries,
        isSingleSelect = true,
        getLabel = { it.desc }
    )

    val osTypeSelection = SelectionPanel(
        title = "操作系统",
        items = EnumOsType.entries,
        getLabel = { it.desc }
    )
        Surface(
            modifier = modifier.fillMaxWidth(),
            tonalElevation = 1.dp,
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // 搜索框
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    label = { Text("搜索软件") },
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        Row {
                            IconButton(
                                onClick = {
                                    onAiSearch(SearchCriteria(
                                        searchText = searchText,
                                        platform = platformSelection.value.firstOrNull() as EnumOsType?,
                                        osTypes = osTypeSelection.value
                                    ))
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = "AI搜索"
                                )
                            }
                            IconButton(
                                onClick = {
                                    onSearch(SearchCriteria(
                                        searchText = searchText,
                                        platform = platformSelection.value.firstOrNull() as EnumOsType?,
                                        osTypes = osTypeSelection.value
                                    ))
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "搜索"
                                )
                            }
                        }
                    }
                )


                Spacer(modifier = Modifier.height(8.dp))

            }
        }
    }


data class SearchCriteria(
    val searchText: String,
    val platform: EnumOsType?,
    val osTypes: Set<EnumOsType>
)
